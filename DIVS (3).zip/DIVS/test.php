<?php
echo "php is correctly installed";

