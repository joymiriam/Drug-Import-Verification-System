-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: divs
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `activity_type` varchar(50) DEFAULT NULL,
  `activity_time` datetime DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `fk_user_activity` (`user_id`),
  CONSTRAINT `fk_user_activity` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (2,29,'User logged out','Logout','2025-03-29 14:57:11'),(3,7,'User logged in','Login','2025-03-29 15:03:53'),(4,NULL,'Registered drug \'\' (ID: 17)','Drug Registration','2025-03-29 15:16:03'),(5,7,'Registered drug \'L MONTUS\' (ID: 18)','Drug Registration','2025-03-29 15:24:58'),(6,7,'Registered a new shipment (ID: )','Shipment Registration','2025-03-29 15:26:32'),(7,7,'Uploaded document \'Radioanalysis certificate (approved)_1.pdf\' for shipment ID: ','Document Upload','2025-03-29 15:28:57'),(8,7,'User logged out','Logout','2025-03-29 15:29:39'),(9,7,'User logged in','Login','2025-03-29 15:29:46'),(10,7,'User logged out','Logout','2025-03-29 15:30:08'),(11,2,'User logged in','Login','2025-03-29 15:30:18'),(12,2,'Importer verification - Importer ID: 16, Status: Approved','Verification','2025-03-29 15:41:57'),(13,2,'Verified drug ID 15 as Rejected','drug','2025-03-29 18:55:32'),(14,2,'Verified manufacturer ID 19 as Approved','manufacturer','2025-03-29 18:59:28'),(15,2,'Verified manufacturer ID 19 as Approved','manufacturer','2025-03-29 19:04:23'),(16,2,'Verified manufacturer ID 10 as Rejected','manufacturer','2025-03-29 19:04:49'),(17,2,'Verified document (ID: 18) - Status: Approved','Document Verification','2025-03-29 19:21:46'),(18,2,'Verified document (ID: 17) - Status: Rejected','Document Verification','2025-03-29 19:22:12'),(19,2,'User logged out','Logout','2025-03-29 16:24:51'),(20,29,'User logged in','Login','2025-03-29 16:25:03'),(21,29,'User logged in','Login','2025-03-29 16:43:17'),(22,29,'User logged in','Login','2025-03-29 16:43:32'),(23,29,'User logged in','Login','2025-03-29 16:43:46'),(24,29,'User logged in','Login','2025-03-29 16:45:00'),(25,29,'Approved shipment ID 18','Shipment Verification','2025-03-29 20:18:55'),(26,29,'User logged out','Logout','2025-03-29 17:19:23'),(27,1,'User logged in','Login','2025-03-29 17:52:21'),(28,7,'User logged in','Login','2025-04-01 17:28:54'),(29,7,'User logged out','Logout','2025-04-01 17:33:20'),(30,7,'User logged in','Login','2025-04-01 17:37:07'),(31,7,'User logged out','Logout','2025-04-01 17:41:38'),(32,7,'User logged in','Login','2025-04-04 18:47:10'),(33,7,'User logged out','Logout','2025-04-04 19:17:26'),(34,2,'User logged in','Login','2025-04-04 19:17:35'),(35,2,'User logged in','Login','2025-04-05 06:16:45'),(36,2,'User logged out','Logout','2025-04-05 07:01:02'),(37,29,'User logged in','Login','2025-04-05 07:01:15'),(38,29,'User logged out','Logout','2025-04-05 07:01:37'),(39,5,'User logged in','Login','2025-04-05 07:01:49'),(40,5,'User logged in','Login','2025-05-02 09:18:05'),(41,29,'User logged in','Login','2025-05-05 15:36:25'),(42,7,'User logged in','Login','2025-05-05 15:36:46'),(43,29,'User logged in','Login','2025-05-05 15:44:04'),(44,29,'User logged in','Login','2025-05-07 10:10:54'),(45,29,'User logged out','Logout','2025-05-07 10:10:57'),(46,5,'User logged in','Login','2025-05-07 10:11:11'),(47,5,'User logged out','Logout','2025-05-07 13:08:45'),(59,7,'User logged in','Login','2025-05-09 06:30:18'),(60,7,'Registered drug \'Kaluma\' (ID: 19)','Drug Registration','2025-05-09 06:32:46'),(61,7,'Registered a new shipment (ID: )','Shipment Registration','2025-05-09 06:34:17'),(62,7,'User logged out','Logout','2025-05-09 06:34:40'),(63,2,'User logged in','Login','2025-05-09 06:35:39'),(64,2,'User logged out','Logout','2025-05-09 06:36:08'),(65,29,'User logged in','Login','2025-05-09 06:36:37'),(66,29,'User logged out','Logout','2025-05-09 06:36:50'),(67,1,'User logged in','Login','2025-05-09 06:36:59'),(68,4,'User logged in','Login','2025-05-09 06:45:28'),(69,4,'User logged out','Logout','2025-05-09 06:45:32'),(70,7,'User logged in','Login','2025-05-09 06:45:44'),(71,7,'User logged in','Login','2025-05-09 12:45:22'),(72,7,'Uploaded document \'Import permit.pdf\' for shipment ID: ','Document Upload','2025-05-09 12:48:10'),(73,7,'Registered drug \'panadol\' (ID: 20)','Drug Registration','2025-05-09 13:05:23'),(74,7,'User logged out','Logout','2025-05-09 13:08:50'),(75,2,'User logged in','Login','2025-05-09 13:09:05'),(76,2,'User logged out','Logout','2025-05-09 13:15:30'),(77,29,'User logged in','Login','2025-05-09 13:15:43'),(78,29,'User logged out','Logout','2025-05-09 13:15:54'),(79,2,'User logged in','Login','2025-05-09 13:16:06'),(80,2,'User logged out','Logout','2025-05-09 13:24:23'),(81,7,'User logged in','Login','2025-05-09 13:24:35'),(82,7,'User logged out','Logout','2025-05-09 13:26:29'),(83,29,'User logged in','Login','2025-05-09 13:26:40'),(84,29,'User logged out','Logout','2025-05-09 13:26:57'),(85,7,'User logged in','Login','2025-05-26 11:28:23'),(86,7,'User logged in','Login','2025-05-28 06:53:13'),(87,7,'Uploaded document \'GMP CERT.pdf\' for shipment ID: ','Document Upload','2025-05-28 07:07:28'),(88,7,'User logged out','Logout','2025-05-28 07:08:02'),(89,NULL,'User logged out','Logout','2025-05-28 07:43:52'),(90,2,'User logged in','Login','2025-05-28 07:44:02'),(91,2,'User logged out','Logout','2025-05-28 09:46:41'),(92,5,'User logged in','Login','2025-05-28 09:46:51'),(93,5,'Registered drug \'glucophage\' (ID: 21)','Drug Registration','2025-05-28 10:22:46'),(94,5,'Registered a new shipment (ID: 20)','Shipment Registration','2025-05-28 10:28:34'),(95,5,'Registered a new shipment (ID: 21)','Shipment Registration','2025-05-28 11:01:14'),(96,5,'Registered drug \'nuteez\' (ID: 22)','Drug Registration','2025-05-28 11:05:33'),(97,5,'User logged out','Logout','2025-05-28 11:11:15'),(98,1,'User logged in','Login','2025-05-28 11:13:00'),(99,1,'User logged out','Logout','2025-05-28 11:15:12'),(100,5,'User logged in','Login','2025-05-28 11:15:38'),(101,5,'User logged out','Logout','2025-05-28 12:44:10'),(102,29,'User logged in','Login','2025-05-28 12:44:20'),(103,29,'User logged out','Logout','2025-05-28 12:44:29'),(104,2,'User logged in','Login','2025-05-28 12:44:42'),(105,2,'User logged out','Logout','2025-05-28 12:46:45'),(106,29,'User logged in','Login','2025-05-28 12:46:56'),(107,29,'User logged out','Logout','2025-05-28 13:01:40'),(108,7,'User logged in','Login','2025-06-06 07:51:44'),(109,7,'User logged out','Logout','2025-06-06 08:00:40'),(110,29,'User logged in','Login','2025-06-06 08:01:05'),(111,29,'User logged out','Logout','2025-06-06 08:05:36'),(112,2,'User logged in','Login','2025-06-06 08:05:59'),(113,2,'User logged out','Logout','2025-06-06 08:11:23'),(114,1,'User logged in','Login','2025-06-06 08:11:33'),(115,1,'User logged out','Logout','2025-06-06 08:20:44'),(116,2,'User logged in','Login','2025-06-06 08:21:06'),(117,2,'User logged out','Logout','2025-06-06 08:23:09'),(118,29,'User logged in','Login','2025-06-06 08:23:30'),(119,29,'User logged out','Logout','2025-06-06 08:54:44'),(120,2,'User logged in','Login','2025-06-06 08:55:38'),(121,7,'User logged in','Login','2025-06-08 12:59:31'),(122,7,'User logged out','Logout','2025-06-08 13:36:21'),(123,2,'User logged in','Login','2025-06-08 13:36:34'),(124,2,'User logged out','Logout','2025-06-08 15:27:33'),(125,2,'User logged in','Login','2025-06-08 15:27:47'),(126,2,'User logged out','Logout','2025-06-08 15:47:20'),(127,29,'User logged in','Login','2025-06-08 15:47:42'),(128,29,'User logged out','Logout','2025-06-08 19:42:55'),(129,1,'User logged in','Login','2025-06-08 19:43:05'),(130,1,'User logged out','Logout','2025-06-08 19:55:34'),(131,28,'User logged in','Login','2025-06-11 11:15:43'),(132,4,'User logged in','Login','2025-06-11 11:17:16'),(133,4,'User logged out','Logout','2025-06-11 11:17:32'),(134,4,'User logged in','Login','2025-06-11 11:24:40'),(135,4,'User logged out','Logout','2025-06-11 11:24:43'),(136,4,'User logged in','Login','2025-06-13 09:37:30'),(137,4,'User logged out','Logout','2025-06-13 09:40:26'),(138,29,'User logged in','Login','2025-06-13 10:23:32'),(139,29,'User logged out','Logout','2025-06-13 10:23:51'),(140,1,'User logged in','Login','2025-06-13 10:26:18'),(141,4,'User logged in','Login','2025-06-13 10:39:38'),(142,4,'User logged out','Logout','2025-06-13 12:05:41'),(143,7,'User logged in','Login','2025-06-13 12:05:52'),(144,7,'User logged out','Logout','2025-06-13 12:36:58'),(145,2,'User logged in','Login','2025-06-13 12:37:14'),(146,2,'Registered manufacturer \'Kinston pharma\' and uploaded GMP certificate','Manufacturer Registration','2025-06-13 14:06:05'),(147,2,'Verified manufacturer ID 4 as Rejected','manufacturer','2025-06-13 17:13:21'),(148,2,'User logged out','Logout','2025-06-13 14:47:53'),(149,29,'User logged in','Login','2025-06-13 14:48:04'),(150,29,'User logged out','Logout','2025-06-13 19:02:24'),(151,1,'User logged in','Login','2025-06-13 19:02:38'),(152,1,'User logged out','Logout','2025-06-13 19:26:08'),(153,7,'User logged in','Login','2025-06-13 19:26:21'),(154,41,'User registered with email: ','User Registration','2025-06-14 11:06:13'),(155,41,'User logged in','Login','2025-06-14 11:06:24'),(156,41,'User logged out','Logout','2025-06-14 11:09:14'),(157,41,'User logged in','Login','2025-06-15 11:04:19'),(158,41,'User logged out','Logout','2025-06-15 11:04:24'),(159,29,'User logged in','Login','2025-06-15 11:04:57'),(160,29,'User logged out','Logout','2025-06-15 11:05:02'),(161,7,'User logged in','Login','2025-06-15 11:19:27'),(162,7,'User logged out','Logout','2025-06-15 11:51:57'),(163,2,'User logged in','Login','2025-06-15 11:52:21'),(164,2,'User logged out','Logout','2025-06-15 12:09:40'),(165,2,'User logged in','Login','2025-06-15 13:29:41'),(166,2,'User logged out','Logout','2025-06-15 15:41:17'),(167,29,'User logged in','Login','2025-06-15 15:41:33'),(168,29,'User logged out','Logout','2025-06-15 17:35:12'),(169,29,'User logged in','Login','2025-06-15 17:35:38'),(170,7,'User logged in','Login','2025-06-16 09:21:46'),(171,7,'User logged in','Login','2025-06-23 09:24:27'),(172,7,'User logged in','Login','2025-06-25 08:10:14'),(173,7,'User logged out','Logout','2025-06-25 10:07:12'),(174,7,'User logged in','Login','2025-06-25 10:07:56'),(175,7,'Registered drug \'ENO\' (ID: 23)','Drug Registration','2025-06-25 10:08:31'),(176,1,'User logged in','Login','2025-06-25 10:14:53'),(177,1,'User logged out','Logout','2025-06-25 10:15:08'),(178,5,'User logged in','Login','2025-06-25 11:13:24'),(179,5,'User logged out','Logout','2025-06-25 11:31:00'),(180,5,'User logged in','Login','2025-06-25 11:31:33'),(181,5,'Registered drug \'amoxicilin\' (ID: 24)','Drug Registration','2025-06-25 11:34:09'),(182,5,'Registered a new shipment (ID: 22)','Shipment Registration','2025-06-25 11:36:22'),(183,5,'Uploaded document \'Transcript.pdf\' for shipment ID: ','Document Upload','2025-06-25 11:39:42'),(184,5,'User logged in','Login','2025-06-28 12:53:33'),(185,29,'User logged in','Login','2025-06-29 12:15:25'),(186,29,'User logged out','Logout','2025-06-29 12:33:49'),(187,1,'User logged in','Login','2025-06-29 12:34:01'),(188,1,'User logged in','Login','2025-06-30 07:21:58'),(189,1,'User logged out','Logout','2025-06-30 07:22:05'),(190,7,'User logged in','Login','2025-06-30 08:44:41'),(191,7,'User logged in','Login','2025-06-30 08:44:42'),(192,7,'User logged out','Logout','2025-06-30 11:22:24'),(193,2,'User logged in','Login','2025-06-30 11:22:35'),(194,2,NULL,NULL,'2025-06-30 14:22:38'),(195,2,NULL,NULL,'2025-06-30 15:10:38'),(196,2,NULL,NULL,'2025-06-30 15:13:24'),(197,2,'User logged out','Logout','2025-06-30 12:14:00'),(198,29,'User logged in','Login','2025-06-30 12:14:17'),(199,29,'User logged out','Logout','2025-06-30 12:14:24'),(200,2,'User logged in','Login','2025-06-30 12:28:38'),(201,5,'User logged in','Login','2025-07-08 12:27:06'),(202,5,'User logged out','Logout','2025-07-08 12:27:11');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `doc_id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(100) DEFAULT NULL,
  `imp_id` int DEFAULT NULL,
  `drug_id` int DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `identification_number` varchar(50) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dou` datetime DEFAULT CURRENT_TIMESTAMP,
  `manuf_id` int DEFAULT NULL,
  PRIMARY KEY (`doc_id`),
  KEY `fk_drug_id` (`drug_id`),
  KEY `documents_ibfk_1` (`imp_id`),
  KEY `documents_ibfk_3` (`manuf_id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`imp_id`) REFERENCES `importer` (`imp_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `documents_ibfk_3` FOREIGN KEY (`manuf_id`) REFERENCES `manufacturer` (`manuf_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_drug_id` FOREIGN KEY (`drug_id`) REFERENCES `drugs` (`drug_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES (1,'Pharmacist Registration',1,1,'Importer','IS10000','uploads/Pharmacist_Registration_IS10000.pdf','2024-12-17 16:35:48',1),(2,'Wholesale Dealer License',2,2,'Importer','WL11000','uploads/Wholesale_Dealer_License_WL11000.pdf','2024-12-17 16:36:17',5),(3,'Certificate of Premises',3,3,'Clearance','CP14000','uploads/Certificate_of_Premises_CP14000.pdf','2024-12-17 16:36:55',3),(4,'Certificate of Analysis',4,4,'Drug','CA13000','uploads/Certificate_of_Analysis_CA13000.pdf','2024-12-17 16:37:20',13),(6,'Product Registration',6,6,'Drug','PR15000','uploads/Product_Registration_PR15000.pdf','2024-12-17 16:38:37',5),(7,'Import Declaration Form',7,7,'Customs','IDF16000','uploads/Import_Declaration_Form_IDF16000.pdf','2024-12-17 16:39:08',12),(8,'Certificate of Conformity',8,8,'Manufacturer','CoC17000','uploads/Certificate_of_Conformity_CoC17000.pdf','2024-12-17 16:39:49',7),(9,'ISM Permit',9,9,'Customs','ISM18000','uploads/ISM_Permit_ISM18000.pdf','2024-12-17 16:40:30',13),(10,'Radioanalysis Certificate',10,10,'Drug','RC19000','uploads/Radioanalysis_Certificate_RC19000.pdf','2024-12-17 16:41:47',20),(11,'Customs Clearance',11,11,'Customs','CC20000','uploads/Customs_Clearance_CC20000.pdf','2024-12-17 16:42:02',6),(12,'Final Inspection Report',12,12,'Clearance','FIR21000','uploads/Final_Inspection_Report_FIR21000.pdf','2024-12-17 16:42:58',7),(13,'customs',NULL,NULL,'radio_analysis','GMP020','uploads/67af7cd0dd5e6_Radioanalysis certificate.pdf','2025-02-14 20:26:40',NULL),(14,'customs',NULL,NULL,'radio_analysis','GMP020','uploads/67af83caa9ed5_Radioanalysis certificate.pdf','2025-02-14 20:56:26',NULL),(15,'importer',3,NULL,'import_license','IL900345','uploads/67d53c2f45cd9_Import permit.pdf','2025-03-15 11:37:03',NULL),(16,'importer',15,NULL,'import_license','IL12234','uploads/67dd9b719446f_Import permit.pdf','2025-03-21 20:01:37',NULL),(17,'importer',15,NULL,'import_license','IL12234','uploads/67dd9ba32eedc_Import permit.pdf','2025-03-21 20:02:27',NULL),(20,'manufacturer',5,NULL,'gmp_certificate','GMP902','uploads/6836b63010d6c_GMP CERT.pdf','2025-05-28 10:07:28',NULL),(21,'Manufacturer',NULL,NULL,'GMP Certificate','GMP 2341','uploads/684c304d61eb4_GMP CERT.pdf','2025-06-13 17:06:05',25),(22,'manufacturer',3,NULL,'gmp_certificate','GMP4213','uploads/685bdffed36bd_Transcript.pdf','2025-06-25 14:39:42',NULL);
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drugs`
--

DROP TABLE IF EXISTS `drugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drugs` (
  `drug_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `batch_no` varchar(50) DEFAULT NULL,
  `dom` date DEFAULT NULL,
  `doe` date DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `strength` varchar(50) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `imp_id` int DEFAULT NULL,
  `manuf_id` int DEFAULT NULL,
  PRIMARY KEY (`drug_id`),
  KEY `drugs_ibfk_1` (`imp_id`),
  KEY `drugs_ibfk_2` (`manuf_id`),
  CONSTRAINT `drugs_ibfk_1` FOREIGN KEY (`imp_id`) REFERENCES `importer` (`imp_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `drugs_ibfk_2` FOREIGN KEY (`manuf_id`) REFERENCES `manufacturer` (`manuf_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drugs`
--

LOCK TABLES `drugs` WRITE;
/*!40000 ALTER TABLE `drugs` DISABLE KEYS */;
INSERT INTO `drugs` VALUES (1,'Paracetamol','B22000','2024-11-01','2026-11-01','Tablet','500mg',1500,1,1),(2,'Ibuprofen','B22001','2024-10-01','2026-10-01','Tablet','400mg',1000,2,5),(3,'Ciprofloxacin','B22002','2024-09-01','2026-09-01','Tablet','500mg',2000,3,3),(4,'Omeprazole','B22003','2024-08-01','2026-08-01','Capsule','20mg',1500,4,13),(5,'Amlodipine','B22004','2024-07-01','2026-07-01','Tablet','5mg',1000,5,20),(6,'Cetirizine','B22005','2024-06-01','2026-06-01','Tablet','10mg',1000,6,5),(7,'Azithromycin','B22006','2024-05-01','2026-05-01','Tablet','250mg',800,7,12),(8,'Amoxicillin','B22007','2024-04-01','2026-04-01','Capsule','500mg',1200,8,7),(9,'Lisinopril','B22008','2024-03-01','2026-03-01','Tablet','10mg',1500,9,13),(10,'Atorvastatin','B22009','2024-02-01','2026-02-01','Tablet','10mg',1200,10,20),(11,'Metformin','B22010','2024-01-01','2026-01-01','Tablet','500mg',1000,11,6),(12,'Diphenhydramine','B22011','2024-12-01','2026-12-01','Tablet','25mg',1500,12,7),(13,'HTC','B234','2024-02-12','2025-02-11','syrup','190gm',80,NULL,NULL),(14,'ENO','B23452','2025-01-20','2027-03-12','Tablets','30gm',123456,NULL,NULL),(15,'ENO','B23452','2025-01-20','2027-03-12','Tablets','30gm',123456,NULL,NULL),(16,'Piroxicam','B5342','2024-01-20','2027-03-30','Tablets','190gm',12314,NULL,NULL),(17,'Gaviscon','AET047','2023-08-11','2025-08-30','liquid','150ml',1290,NULL,NULL),(18,'L MONTUS','M1284A','2024-10-20','2026-09-10','Tablets','15mg',3000,NULL,NULL),(19,'Kaluma','B3251','2024-01-12','2027-08-20','Tablets','50mg',12345,NULL,NULL),(20,'panadol','B23452','2024-09-21','2025-09-01','Tablets','15mg',4321,NULL,NULL),(21,'glucophage','C24047','2024-02-12','2027-03-12','Tablets','500mg',76345,NULL,NULL),(22,'nuteez','C240470','2024-02-12','2027-03-12','SYRUP','150ml',654,NULL,NULL),(23,'ENO','B234','2024-02-12','2027-03-12','Tablets','190gm',123345678,NULL,NULL),(24,'amoxicilin','B3455','2024-01-12','2027-12-30','Tablets','150mg',6543,NULL,NULL);
/*!40000 ALTER TABLE `drugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importer`
--

DROP TABLE IF EXISTS `importer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `importer` (
  `imp_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `license_no` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `registration_no` varchar(50) DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`imp_id`),
  KEY `fk_importer_user` (`user_id`),
  CONSTRAINT `fk_importer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importer`
--

LOCK TABLES `importer` WRITE;
/*!40000 ALTER TABLE `importer` DISABLE KEYS */;
INSERT INTO `importer` VALUES (1,'BLAKLINE CONSULTING LIMITED','0712345678','PARKLANDS','BU202405135','blakeline@gmail.com','PPB/B/7392',3),(2,'IKIGAI HEALTH KENYA LTD','0723456789','CHAMBERS ROAD','BU202412119','ikigai@gmail.com','PPB/I/10306',4),(3,'MULTIBASE PHARMA INDUSTRIES LIMITED','0734567890','JALARAM ROAD -WESTLANDS','BU202410778','multibase@gmail.com','PPB/M/9918',5),(4,'PHARMA & ALLIED LOGISTICS LTD - EMBU','0701234567','DAYA SN ROAD, Embu','BU202500072','pharma@gmail.com','PPB/P/3101',6),(5,'PHILMED LIMITED - BUSIA','0725123487','OPPOSITE BUSIA STADIUM','BU202411975','philmed@gmail.com','PPB/P/5015',7),(6,'VEZKAM LIMITED','0745123456','MUSHEMBI ROAD','BU202407527','vezkam@gmail.com','PPB/V/434',8),(7,'4K HEALTHCARE LTD (Nairobi)','0799123456','WOODVALE GROOVE, Nairobi','BU202403703','health4@gmail.com','PPB/4/1',9),(8,'A&Z NUTRACEUTICALS LIMITED','0721123456','NGARA ROAD','BU202407015','aznutra@gmail.com','PPB/A/3102',10),(9,'BELEA PHARMACY LIMITED (MACHAKOS)','0733123456','NEXT TO MACHAKOS BUS PARK','BU202411366','belea@gmail.com','PPB/B/7366',11),(10,'BEL CAREMAX LIMITED (Uasin Gishu)','0748123456','MAKASEMBO STREET, Uasin Gishu','BU202402723','caremax@gmail.com','PPB/B/7363',12),(11,'CAAV CARE PHARMACEUTICALS LIMITED','0708123456','UTAWALA STREET','BU202410302','caavcare@gmail.com','PPB/C/9373',13),(12,'CITADEL PHARMACEUTICALS LTD-DIGO RD (Mombasa)','0716123456','MOI AVENUE, Mombasa','BU202409032','citadelpharm@gmail.com','PPB/C/165',14),(13,'ELEMENTAITA PHARMACEUTICALS LIMITED (Kericho)','0717123456','MOI ROAD TENGECHA, Kericho','BU202406892','element@gmail.com','PPB/E/059',15),(14,'GALAXY PHARMACEUTICALS LTD - KISUMU (Kisumu)','0728123456','Kisumu','BU202500169','galaxy@gmail.com','PPB/G/103',16),(15,'FOURMEDS PHARMACEUTICALS LIMITED','0739123456','THIKA ROAD','BU202501573','fourmeds@gmail.com','PPB/F/3112',17),(16,'GREENWORLD PHARMACEUTICALS LIMITED (Nairobi)','0709123456','THETA LANE , OFF LENANA ROAD, Nairobi','BU202401462','greenworld@gmail.com','PPB/G/1411',18),(17,'INTERNATIONAL COMMITTEE OF THE REDCROSS (Nairobi)','0711345678','Nairobi','BU202500944','icredcross@gmail.com','PPB/I/83 B',19),(18,'JACKS PHARMACY (Kisii)','0723345678','Kisii','BU202400666','jackpharma@gmail.com','PPB/J/128',20),(19,'KENDOR ENTERPRISES LIMITED (Nairobi)','0734345678','MSAPO CLOSE, Nairobi','BU202409576','kendoreenter@gmail.com','PPB/K/905',21),(20,'KONTUSS GROUP LTD','0741345678','OSIELI ROAD','BU202407517','kontuss@gmail.com','PPB/K/7584',22),(21,'MATIBABU FOUNDATION PHARMACY (Siaya)','0702345678','KISUMU-BUSIA ROAD, Siaya','BU202406105','matibabu@gmail.com','PPB/M/8581',23),(22,'MASAKU CHEMIST (Machakos)','0713345678','MULU MUTISYA, Machakos','BU202500971','masaku@gmail.com','PPB/M/55',24),(25,'Vrudando','0712324241','Express 12, UK','L34235','Vrudando@gmail.com','12345678',41);
/*!40000 ALTER TABLE `importer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manufacturer` (
  `manuf_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gmp_certNo` varchar(50) DEFAULT NULL,
  `doi` date DEFAULT NULL,
  `gmp_cert_verif` tinyint(1) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`manuf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturer`
--

LOCK TABLES `manufacturer` WRITE;
/*!40000 ALTER TABLE `manufacturer` DISABLE KEYS */;
INSERT INTO `manufacturer` VALUES (1,'HAB PHARMACEUTICALS & RESEARCH LIMITED','PLOT NO. 10 PHARMACITY SIDCUL SELAQUI, INDIA','GMP12000','2024-01-01',1,'habpharma@gmail.com'),(2,'Merck KGaA','Frankfurter Strabe 250, Darmstadt, GERMANY','GMP12001','2023-12-15',1,'merck@gmail.com'),(3,'MEDOPHARM','NO. 34B, INDUSTRIAL AREA, MALUR, KOLAR DIST, INDIA','GMP12002','2023-11-20',1,'medopharm@gmail.com'),(4,'ITALFARMACO S.P.A','VIALE F. TESTI, 330, MILAN, ITALY','GMP12003','2023-10-10',0,'italfarma@gmail.com'),(5,'SHIJIAZHUANG NO.4 PHARMACEUTICAL CO., LTD','YANGZI ROAD, ECONOMIC & TECHNOLOGICAL DEVELOPMENT, CHINA','GMP12004','2023-09-05',1,'shijiazhuang@gmail.com'),(6,'Schering Plough Labo N.V.','Industriepark 30, Zone A, Heist-Op-den-Berg, BELGIUM','GMP12005','2023-08-20',1,'schering@gmail.com'),(7,'Delta Pharma Limited','House # 501, Road # 34, New DOHS, Mohakhali, Dhaka, BANGLADESH','GMP12006','2023-07-15',0,'delta@gmail.com'),(8,'CSPC Zhongnuo No.2 Manufacturing','No.6 Huaxing Road, Zhonghua South Street, Shijiazhuang City, CHINA','GMP12007','2023-06-01',1,'zhongnuo@gmail.com'),(9,'Catalent UK Swindon Zydis Limited','Frankland Road, Wiltshire, UNITED KINGDOM','GMP12008','2023-05-10',1,'catalent@gmail.com'),(10,'B.BRAUN MEDICAL AG - SEMPACH SWITZERLAND','SEESATZ 17, CH-6204 SEMPACH, SWITZERLAND','GMP12009','2023-04-25',0,'b.braun@gmail.com'),(11,'Interchemie werken \"De Adelaar\" B.V.','Metaalweg 8, Venray, NETHERLANDS','GMP12010','2023-03-15',1,'interch@gmail.com'),(12,'STANFORD LABORATORIES PVT LTD','8, INDUSTRIAL AREA, MEHAPTUR, DIST UNA, INDIA','GMP12011','2023-02-05',1,'stanfordlab@gmail.com'),(13,'Glenmark Pharmaceuticals Limited, GOA','Plot no. S-7, Colvale Industrial Estate, Colvale, INDIA','GMP12012','2023-01-01',1,'glenmark@gmail.com'),(14,'Zoetis Inc., Charles City','2000 Rockford Road, Iowa, UNITED STATES','GMP12013','2022-12-20',1,'zoetis@gmail.com'),(15,'PAR Laboratories','Plot No. 34, G.I.D.C, Gozaria, Gujarat, INDIA','GMP12014','2022-11-15',1,'parlab@gmail.com'),(16,'PHARMACIA AND UPJOHN COMPANY','7000 PORTAGE ROAD, KALAMAZOO, MICHIGAN, UNITED STATES','GMP12015','2022-10-01',1,'phrmacia@gmail.com'),(17,'PFIZER PGM','AMBOISE 29, ROUTE DES INDUSTRIES, POCE SUR CISSE, FRANCE','GMP12016','2022-09-10',1,'pfizer@gmail.com'),(18,'R-PHARM GERMANY GMBH','HEINRICH MACH STR. 35, ILLERTISSEN, GERMANY','GMP12017','2022-08-15',1,'rpharm@gmail.com'),(19,'BSP Pharmaceuticals S.p.A','Via Appia, Scalo, Latina (LT), ITALY','GMP12018','2022-07-05',1,'bsppharm@gmail.com'),(20,'Novartis Turkey','Yenisehir Mahallesi Ihlara Vadisi Sokak, No:2, Kurtkoy, Pendik/Istanbul, TURKEY','GMP12019','2022-06-20',1,'novartis@gmail.com'),(21,'Devki','1195','GMP9889','2024-05-09',0,'devki@gmail.com'),(22,'Joy Mugo','1195','uf5878','2009-08-09',1,'jmiriam.mugo@gmail.com'),(23,'RNB','9098USA','GMP 5789','2024-08-02',1,'rnb@gmail.com'),(24,'BR Pharmaceuticals','leeds, LS166QE, UK','GMP 245768','2024-05-09',1,'brpharmaceuticals.@gmail.com'),(25,'Kinston pharma','1195','GMP 2341','2024-05-09',1,'kingstoneph@gmail.com');
/*!40000 ALTER TABLE `manufacturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment`
--

DROP TABLE IF EXISTS `shipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment` (
  `ship_id` int NOT NULL AUTO_INCREMENT,
  `imp_id` int DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `port_of_entry` varchar(100) DEFAULT NULL,
  `doa` date DEFAULT NULL,
  `drug_id` int DEFAULT NULL,
  PRIMARY KEY (`ship_id`),
  KEY `fk_shipment_drug_id` (`drug_id`),
  KEY `shipment_ibfk_1` (`imp_id`),
  CONSTRAINT `fk_shipment_drug_id` FOREIGN KEY (`drug_id`) REFERENCES `drugs` (`drug_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `shipment_ibfk_1` FOREIGN KEY (`imp_id`) REFERENCES `importer` (`imp_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment`
--

LOCK TABLES `shipment` WRITE;
/*!40000 ALTER TABLE `shipment` DISABLE KEYS */;
INSERT INTO `shipment` VALUES (1,1,'Air','Qatar Airways','Jomo Kenyatta International Airport (JKIA)','2025-01-15',1),(2,2,'Sea','Mediterranean Shipping Company (MSC)','Port of Mombasa','2025-02-20',2),(3,3,'Air','Singapore Airlines','Moi International Airport (MIA)','2025-03-05',3),(4,4,'Road','CMA CGM','Malaba One Stop Border Post (OSBP)','2025-03-12',4),(5,5,'Air','Emirates Airlines','Eldoret International Airport (EIA)','2025-04-01',5),(6,6,'Road','Hapag-Lloyd','Busia One Stop Border Post (OSBP)','2025-04-15',6),(7,7,'Road','Maersk Line','Isebania One Stop Border Post (OSBP)','2025-05-10',7),(8,8,'Sea','MSC Mediterranean Shipping','Inland Container Depot, Nairobi (ICDN)','2025-06-01',8),(9,9,'Air','KLM Royal Dutch Airlines','Lunga Lunga One Stop Border Post (OSBP)','2025-07-18',9),(10,10,'Sea','Maersk Line','Jomo Kenyatta International Airport (JKIA)','2025-08-03',10),(11,11,'Air','Qatar Airways','Jomo Kenyatta International Airport (JKIA)','2025-09-12',11),(12,12,'Sea','Mediterranean Shipping Company (MSC)','Port of Mombasa','2025-10-05',12),(13,NULL,'air','Stock Flow','JKIA','2025-03-10',NULL),(14,15,'Water','Maersk','Port of Mombasa','2025-05-10',NULL),(15,15,'Water','Stock Flow','Port of Mombasa','2026-09-29',NULL),(16,15,'Air','Lusha','JKIA','2026-04-10',16),(17,5,'Water','Lusha','JKIA','2025-04-12',17),(18,5,'Air','Maersk','Mombasa Airport','2025-12-02',18),(19,5,'land','Daniels','Namanga','2025-12-29',19),(20,3,'land','Maersk','Port of Mombasa','2025-09-12',21),(21,3,'Water','Maersk','Port of Mombasa','2026-02-10',21),(22,3,'Water','Maersk','Port of Mombasa','2026-10-21',24);
/*!40000 ALTER TABLE `shipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'jojo','$2y$12$4o.o8kPwh6t3xd7GFDguZupVkSe9mAhad1iC5JpM6otPzWKZs9ANa','admin','0780991023','grace@gmail.com','Joy','Mugo'),(2,'cindy','$2y$12$KFyZv7Qe25wMxIMbfAP8Q.L1hpMoQYNH3L.kN8N7E9/MyXDxIx0SW','ppb','0712345678','cynthia@eric.com','Cynthia','Eric'),(3,'prez','$2y$12$/.v5SjJMq.Y8B1oO9MM/ReNqJX546wfQ3t61oKm0SJVFfyMuYegOy','importer','0798765432','barrack@obama.com','Barrack','Obama'),(4,'Jose','$2y$12$UWXMeGkZnjFRhdCR2GTCeO1ddfzVlfXW1cjxSbPruI3fTNLmkOd/G','importer','0799887766','Josephmwangi@gmail.com','Joseph','Mwangi'),(5,'pressy','$2y$12$EjCyoplABzHWQlpNoUpd4O5EMfdzfL5nSmeFwtEGyR8.LYuaPMjxS','importer','0722113344','precious@gmail.com','Precious ','Njeri'),(6,'johnD','$2y$12$LVi.DQtQ3s7uzTKWockZguNUbYJpff9OC5wMOYjbe3fBWyYN5LsJu','importer','0712345678','blakeline@gmail.com','John','Doe'),(7,'peterK','$2y$12$mtHnu3yvOkmesYmKt/D7jeOyN.P.GXEYvhTdpbBX.Fhq55WZfUgpK','importer','0723456789','ikigai@gmail.com','Peter','Kimani'),(8,'maryW','$2y$12$JOAjo8aDoFJuA7ezKTzuye7HLE7lF5AZBfNb7SorI.fIFRU887Knu','importer','0734567890','multibase@gmail.com','Mary','Wanjiru'),(9,'jamesM','$2y$12$rzqM5EcmzHsTeAwmNjmwVu5zGl6DpPDpd/0YBY9ciOr6utPxAWmbe','importer','0701234567','pharma@gmail.com','James','Maina'),(10,'aliceN','$2y$12$h2Yj/TQLlYetZlAlNsoIdekRvLRyOoznCa60sJvlO3C/ft82sihia','importer','0725123456','philmed@gmail.com','Alice','Ndegwa'),(11,'frankO','$2y$12$n2Vq4MLJCy43FEKamWbuieUEgPIN/7/36Iks7TnFPn7sh/d5IPaHy','importer','0745123456','vezkam@gmail.com','Frank','Odhiambo'),(12,'paulT','$2y$12$ttHXvELCAJ6399CKe4TTo.0IkNL1LLk97aKAeuRY/XiBPBBZppTsm','importer','0799123456','health4@gmail.com','Paul','Tumbo'),(13,'nancyK','$2y$12$VRMGmAa/ZIlXOIcSXKrv8eIFAcLP1OvOulMn6ozCalO9bHV5y25gS','importer','0721123456','aznutra@gmail.com','Nancy','Kariuki'),(14,'georgeM','$2y$12$lRBkZdPzbpLfNPHv/bWPo.oKdIW4QNaUZirkgcH1SooTLJdv18jOS','importer','0733123456','belea@gmail.com','George','Mutua'),(15,'lucyW','$2y$12$CqdwwVnIp/vynH3EP6Bim.rc/Tro9mPBs/ofqvGETF/snP2BtbX7q','importer','0748123456','caremax@gmail.com','Lucy','Wairimu'),(16,'vincentO','$2y$12$HwNWy5cCV2PPX/IikzGNzOJMui6pR2nJN9Yqds/yP.MKNKqzhWB/q','importer','0708123456','caavcare@gmail.com','Vincent','Otieno'),(17,'susanN','$2y$12$dVPEjNDit3V4psxYVbo6ZuIrdWUqYSto/RyuXx4wkF6ZU/NFFUXSG','importer','0716123456','citadelpharm@gmail.com','Susan','Njeri'),(18,'danielK','$2y$12$LQ888HuReoJ6ZXwkdYDS7eDPSP83PR5cYpD7QRXPxxgmh./zpg17u','importer','0717123456','element@gmail.com','Daniel','Kamau'),(19,'patrickM','$2y$12$Jpp6oIwyHEq1h8DEsnmCSuxGMUFnJVkS4OlhVnvtSpT8hPntJc8US','importer','0728123456','galaxy@gmail.com','Patrick','Mwaura'),(20,'edithA','$2y$12$hdCzcm.7NTApWtyO3QVy4eips49Sju/3PY6cNWfEcvrWP49HoGEEa','importer','0739123456','fourmeds@gmail.com','Edith','Achieng'),(21,'ericW','$2y$12$hN8e3IRKQG/qkT4JqvjZGOhWsXiVNokKasZNjlMIrRG/ipf8m/QFS','importer','0709123456','greenworld@gmail.com','Eric','Wekesa'),(22,'carolineR','$2y$12$yFbjdDV2bg45ayQfAw9AzelbgBoAsBeRpvT209RAjQOgsCUg6cOzq','importer','0711345678','icredcross@gmail.com','Caroline','Rono'),(23,'kennedyJ','$2y$12$8dAJ7cMX8vypbR0u9qo9ceg2/yqhTuBkSB6TtQRViEY72B2/d1ul.','importer','0723345678','jackpharma@gmail.com','Kennedy','Juma'),(24,'josephK','$2y$12$KVHGThltvqh7SewkwGVUY.WVraCJ2wJcjNukljBtHYsvyE0cygBbW','importer','0734345678','kendoreenter@gmail.com','Joseph','Karanja'),(25,'hannahO','$2y$12$TyC1aS4CwVPou5F2s.YDj.vcLYVYM5N7BF0.ab0UqKCNsg41MHzjG','importer','0741345678','kontuss@gmail.com','Hannah','Omondi'),(26,'stephenM','$2y$12$VXsebKIFJ8YsfkBVxgzuIe7FiZ4zc7aWdbwFmDg7QmPbIAomwEPpS','importer','0702345678','matibabu@gmail.com','Stephen','Mugambi'),(27,'sarahL','$2y$12$2DXCOvpmSFw.B84p.1RR1OWu3qKyH3FXk2Q3EhZD2SedDuYOj3Oiu','importer','0713345678','masaku@gmail.com','Sarah','Limo'),(28,'kev','$2y$12$yvQfewWRVhJHFcio9Hn42.SHNOai46HUtFI.8Abwv20BRpORvtXqy','importer','0112233445','Kevinhart@gmail.com','kevin','hart'),(29,'shelly','$2y$12$EHnnxT4v74wqGNs5dh93Gul1Ha30.XGcknTD4kRMe2w7mLbJ8daFW','Customs','0723176338','bocoyolo5678@gmail.com','Sheldon','Cooper'),(40,'Tom','$2y$12$uHeoEApslwlQVvFm5bybM.FBfQZr9omNA0QqOWlHxSKLiqF6Ixc82','PPB','0782345612','Thomasm@gmail.com','Thomas','Martin'),(41,'jacky','$2y$12$EXLY6vJ6Szafg9BwsW0Ig.kTkgOaGhSxH04DI5dy27kQUof.IiTRG','importer','0709824328','jackline@gmail.com','Jackline','Nyokabi');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification`
--

DROP TABLE IF EXISTS `verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification` (
  `verif_id` int NOT NULL AUTO_INCREMENT,
  `imp_id` int DEFAULT NULL,
  `doc_id` int DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `dov` date DEFAULT NULL,
  `inspector_name` varchar(100) DEFAULT NULL,
  `rejection_reason` varchar(255) DEFAULT NULL,
  `manuf_id` int DEFAULT NULL,
  `drug_id` int DEFAULT NULL,
  `ship_id` int DEFAULT NULL,
  PRIMARY KEY (`verif_id`),
  KEY `fk_verification_drug_id` (`drug_id`),
  KEY `verification_ibfk_2` (`doc_id`),
  KEY `verification_ibfk_1` (`imp_id`),
  KEY `verification_ibfk_3` (`manuf_id`),
  CONSTRAINT `fk_verification_drug_id` FOREIGN KEY (`drug_id`) REFERENCES `drugs` (`drug_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `verification_ibfk_1` FOREIGN KEY (`imp_id`) REFERENCES `importer` (`imp_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `verification_ibfk_2` FOREIGN KEY (`doc_id`) REFERENCES `documents` (`doc_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `verification_ibfk_3` FOREIGN KEY (`manuf_id`) REFERENCES `manufacturer` (`manuf_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification`
--

LOCK TABLES `verification` WRITE;
/*!40000 ALTER TABLE `verification` DISABLE KEYS */;
INSERT INTO `verification` VALUES (1,1,1,'Approved','2025-01-15','John Onyango','',1,1,1),(2,2,2,'Rejected','2025-01-16','Jane Wanja','Incomplete documents',5,2,2),(3,3,3,'Approved','2025-01-17','Alice Wakesho','',3,3,3),(4,4,4,'Approved','2025-01-18','Michael Maina,','',13,4,4),(6,6,6,'Approved','2025-01-20','David Wilson','',5,6,6),(7,7,7,'Approved','2025-01-21','Sarah Wangari','',12,7,7),(8,8,8,'Approved','2025-01-22','Christopher Maingi','',7,8,8),(9,9,9,'Approved','2025-01-23','Rachel Okelo','',13,9,9),(10,10,10,'Approved','2025-01-24','Kevin Martin','',20,10,10),(11,11,11,'Rejected','2025-01-25','Linda Kamau','No inspection report',6,11,11),(12,12,12,'Approved','2025-01-26','Daniel Lewis','',7,12,12),(13,1,NULL,'Approved','2024-10-09','joy','',NULL,NULL,NULL),(14,13,NULL,'Approved','2025-03-25','Cynthia Eric','',NULL,NULL,NULL),(15,13,NULL,'Approved','2025-03-25','Cynthia Eric','',NULL,NULL,NULL),(16,14,NULL,'Approved','2025-03-25','Cynthia Eric','',NULL,NULL,NULL),(17,14,NULL,'Approved','2025-03-25','Cynthia Eric','',NULL,NULL,NULL),(18,14,NULL,'Approved','2025-03-25','Cynthia Eric','',NULL,NULL,NULL),(19,14,NULL,'Approved','2025-03-25',' ','',NULL,NULL,NULL),(20,14,NULL,'Approved','2025-03-25',' ','',NULL,NULL,NULL),(21,14,NULL,'Approved','2025-03-25',' ','',NULL,NULL,NULL),(22,13,NULL,'Approved','2025-03-25',' ','',NULL,NULL,NULL),(23,15,NULL,'Rejected','2025-03-25','Cynthia Eric','Expired certificate',NULL,NULL,NULL),(24,22,NULL,'Approved','2025-03-25','Cynthia Eric',NULL,NULL,NULL,NULL),(25,14,NULL,'Rejected','2025-03-25','Cynthia Eric','double entry',NULL,14,NULL),(26,14,NULL,'Approved','2025-03-25','Cynthia Eric','',22,NULL,NULL),(27,14,NULL,'Approved','2025-03-25','Cynthia Eric','',21,NULL,NULL),(28,13,13,'Approved','2025-03-25','Cynthia Eric','',NULL,NULL,NULL),(29,13,NULL,'Approved','2025-03-25','Cynthia Eric','',NULL,NULL,13),(30,13,NULL,'Approved','2025-03-29','Cynthia Eric','',NULL,NULL,14),(31,15,NULL,'Approved',NULL,NULL,'',NULL,NULL,15),(32,15,NULL,'Rejected',NULL,NULL,'no documents',NULL,NULL,16),(33,16,NULL,'Approved','2025-03-29','Cynthia Eric',NULL,NULL,NULL,NULL),(34,18,NULL,'Approved','2025-03-29','Cynthia Eric',NULL,NULL,18,NULL),(35,13,NULL,'Rejected','2025-03-29','Cynthia Eric','No GMP certificate for the manufacturer',NULL,13,NULL),(36,17,NULL,'Approved','2025-03-29','Cynthia Eric',NULL,NULL,17,NULL),(37,16,NULL,'Approved','2025-03-29','Cynthia Eric',NULL,NULL,16,NULL),(38,15,NULL,'Rejected','2025-03-29','Cynthia Eric','double entry',NULL,15,NULL),(39,19,NULL,'Approved','2025-03-29','Cynthia Eric','',19,NULL,NULL),(40,19,NULL,'Approved','2025-03-29','Cynthia Eric','',19,NULL,NULL),(41,10,NULL,'Rejected','2025-03-29','Cynthia Eric','GMP certificate unverified',10,NULL,NULL),(42,16,16,'Approved','2025-03-29','Cynthia Eric','',NULL,NULL,NULL),(43,16,16,'Approved','2025-03-29','Cynthia Eric','',NULL,NULL,NULL),(46,17,17,'Rejected','2025-03-29','Cynthia Eric','false license',NULL,NULL,NULL),(47,17,NULL,'Approved',NULL,NULL,'',NULL,NULL,17),(48,18,NULL,'Approved',NULL,NULL,'',NULL,NULL,18),(49,18,NULL,'Approved',NULL,NULL,'',NULL,NULL,18),(50,NULL,NULL,'Rejected','2025-06-13','Cynthia Eric','GMP certificate unverified',4,NULL,NULL),(51,NULL,NULL,'Approved','2025-06-30','Cynthia Eric','',NULL,NULL,22);
/*!40000 ALTER TABLE `verification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08 16:06:28
